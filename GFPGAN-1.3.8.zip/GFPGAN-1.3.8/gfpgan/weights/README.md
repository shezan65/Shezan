# Weights

Put the downloaded weights to this folder.
